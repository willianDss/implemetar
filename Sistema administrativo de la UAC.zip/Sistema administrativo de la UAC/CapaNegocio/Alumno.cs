﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio
{
    public class Alumno
    {
        // atributos
        private string apellidos;
        private string nombres;
        private int edad;
        private string lugarNacimiento;
        // propiedades
        public string Apellidos
        {
            get { return apellidos; } // lectura de atributos
            set { apellidos = value; } // escritura de atributos
        }
        public string Nombres
        {
            get { return nombres; }
            set { nombres = value; }
        }
        public int Edad
        {
            get { return edad; }
            set { edad = value; }
        }
        public string LugarNacimiento
        {
            get { return this.lugarNacimiento; }
            set { this.lugarNacimiento = value; }
        }

        // metodos u operaciones
        public string Estudiar()
        {
            return "no se ha implementado el metodo estudiar";
        }
        public string Trabajar()
        {
            return "no se ha implementado el metodo trabajar";
        }
        public string AprobarExamen()
        {
            return "no se ha implementado el metodo aprobar examen";
        }
    }
}
